# -*- coding: utf-8 -*-
"""
Created on Tue Jun 15 11:57:09 2021
This program is used to plot the DAC2Voltage Calibration data
"""
import numpy as np
import matplotlib.pyplot as plt
import LT.box as B

d = np.loadtxt('C:/Users/Plasma/Desktop/Power_Supply_Control/Calibration_data/CH8_ADC_Current.txt')


DAC  = d[:,0]
ADC  = d[:,1]
I1   = d[:,2]


#Plotting the Voltage Calibration data:
plt.figure(1)
plt.plot(ADC, I1, label='I1', marker = 'o')
plt.xlabel('ADC Analog Number')
plt.ylabel('Current')
plt.legend()

p = B.polyfit(ADC, I1)
B.plot_exp(ADC, I1)
B.plot_line(p.xpl, p.ypl)

#cH1: -74.543 + 5.28655*x + -0.00711837*x**2
#CH1(0,0): -62.331935 + 4.85125979 *x + -0.00442242 * x**2
#Ch2: -105.0063 + 6.39321*x + -0.0127550*x**2
#Ch3:  -76.619157+ 6.036568*x  + -0.0116926*x**2
#CH4: -71.404885+ 5.7239559*x  + -0.009316969*x**2
#CH5: -50.8986 +6.22277808*x +  -0.0150564*x**2 
#CH6: -50.334347 + 5.681186*x + -0.0100215*x**2 
#CH7: -36.77497 + 4.676001*x + -0.0022123*x**2 
#CH8: -54.452022 + 5.2206166 *x + -0.0061142*x**2  
"""
def current(x):
    return -54.452022 + 5.2206166 *x + -0.0061142*x**2  
"""

plt.show()