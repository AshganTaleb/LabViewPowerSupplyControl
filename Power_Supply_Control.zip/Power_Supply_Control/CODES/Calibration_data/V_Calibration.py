# -*- coding: utf-8 -*-
"""
Created on Tue Jun 15 11:57:09 2021
This program is used to plot the DAC2Voltage Calibration data
"""
import numpy as np
import matplotlib.pyplot as plt

d = np.loadtxt('C:/Users/Plasma/Documents/CODES/Calibration_data/DAC2Voltage_Calibration.txt')


DAC = d[:,0]
V1  = d[:,1]
V2  = d[:,2]
V3  = d[:,3]
V4  = d[:,4]
V5  = d[:,5]
V6  = d[:,6]
V7  = d[:,7]
V8  = d[:,8]

#Plotting the Voltage Calibration data:
plt.figure(1)
plt.plot(DAC, V1, label='V1')
plt.plot(DAC, V2, label='V2')
plt.plot(DAC, V3, label='V3')
plt.plot(DAC, V4, label='V4')
plt.plot(DAC, V5, label='V5')
plt.plot(DAC, V6, label='V6')
plt.plot(DAC, V7, label='V7')
plt.plot(DAC, V8, label='V8')

plt.xlabel('DAC Analog Number')
plt.ylabel('Voltage')
plt.legend()





plt.show()