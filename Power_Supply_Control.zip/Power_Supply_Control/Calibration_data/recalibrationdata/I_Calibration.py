# -*- coding: utf-8 -*-
"""
Created on Tue Jun 15 11:57:09 2021
This program is used to plot the DAC2Voltage Calibration data
"""
import numpy as np
import matplotlib.pyplot as plt
import LT.box as B

d = np.loadtxt('CH1_ADC_Current.txt')


ADC = d[:,0]
I1  = d[:,1]


#Plotting the Voltage Calibration data:
plt.figure(1)
plt.plot(ADC, I1, label='I1', marker = 'o')
p = B.polyfit(ADC, I1)

chisq/dof =  136.3327661550012

parameter [ 0 ] =  -74.54367305017695  +/-  5.168131514705901
parameter [ 1 ] =  5.286552785604954  +/-  0.207927991139808
parameter [ 2 ] =  -0.007118378160984484  +/-  0.001386320756340315
 def current(x):
    return -74.543 + 5.28655*x + -0.00711837*x**2

plt.xlabel('ADC Analog Number')
plt.ylabel('Current')
plt.legend()





plt.show()