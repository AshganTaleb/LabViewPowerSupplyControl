import numpy as np
import LT.box as B
from scipy.interpolate import UnivariateSpline as spline
#%% Data File
DD = B.get_file('Channel. Calibration.data')
A = DD['Analog']
V1 = DD['V1']
V2 = DD['V2']
V3 = DD['V3']
V4 = DD['V4']
V5 = DD['V5']
V6 = DD['V6']
V7 = DD['V7']
V8 = DD['V8']
dV = DD['err']
#%% Defining Limits
def get_view(x):
    x1,x2 = B.pl.xlim()
    s = (x1<=x)&(x<=x2)
    return s
#%% Plotting the data sets as lines
B.plot_line(A, V1, label ='V1')
B.plot_line(A, V2, label ='V2')
B.plot_line(A, V3, label ='V3')
B.plot_line(A, V4, label ='V4')
B.plot_line(A, V5, label ='V5')
B.plot_line(A, V6, label ='V6')
B.plot_line(A, V7, label ='V7')
B.plot_line(A, V8, label ='V8')
B.pl.xlabel('Analog')B.pl.ylabel('Voltage')`.pl.title('Voltage Calibration')
B.pl.legend()
#%% Plotting the data sets
B.pl.figure()
B.plot_exp(A, V1, label ='V1')
B.plot_exp(A, V2, label ='V2')
B.plot_exp(A, V3, label ='V3')
B.plot_exp(A, V4, label ='V4')
B.plot_exp(A, V5, label ='V5')
B.plot_exp(A, V6, label ='V6')
B.plot_exp(A, V7, label ='V7')
B.plot_exp(A, V8, label ='V8')
B.pl.xlabel('Analog')
B.pl.ylabel('Voltage')
B.pl.title('Voltage Calibration')
B.pl.legend()

#%% Interpolating the data sets
B.pl.figure()
# Channel 1
s1 = spline(A, V1, s = 1)
xs = np.linspace(0, 1023, 1000)
ys = s1(xs)
B.plot_exp(A, V1, dV, label = 'V1')
B.plot_line(xs, ys, color = 'blue')
# Channel 2
s2 = spline(A, V2, s = 1)
xs = np.linspace(0, 1023, 1000)
ys = s2(xs)
B.plot_exp(A, V2, dV, label = 'V2')
B.plot_line(xs, ys, color = 'orange')
# Channel 3
s3 = spline(A, V3, s = 1)
xs = np.linspace(0, 1023, 1000)
ys = s3(xs)
B.plot_exp(A, V3, dV, label = 'V3')
B.plot_line(xs, ys, color = 'green')
# Channel 4
s4 = spline(A, V4, s = 1)
xs = np.linspace(0, 1023, 1000)
ys = s4(xs)
B.plot_exp(A, V4, dV, label = 'V4')
B.plot_line(xs, ys, color = 'red')
# Channel 5
s5 = spline(A, V5, s = 1)
xs = np.linspace(0, 1023, 1000)
ys = s5(xs)
B.plot_exp(A, V5, dV, label = 'V5')
B.plot_line(xs, ys, color = 'purple')
# Channel 6
s6 = spline(A, V6, s = 1\54444x
xs = np.linspace(0, 1023, 1000)
ys = s6(xs)
B.plot_exp(A, V6, dV, label = 'V6')
B.plot_line(xs, ys, color = 'brown')
#Channel 7
s7 = spline(A, V7, s = 1)
xs = np.linspace(0, 1023, 1000)
ys = s7(xs)
B.plot_exp(A, V7, dV, label = 'V7')
B.plot_line(xs, ys, color = 'pink')
# Channel 8
s8 = spline(A, V8, s = 1)
xs = np.linspace(0, 1023, 1000)
ys = s8(xs)
B.plot_exp(A, V8, dV, label = 'V8')
B.plot_line(xs, ys, color = 'gray')
B.pl.xlabel('Analog')
B.pl.ylabel('Voltage')
B.pl.title('Voltage Calibration')
B.pl.legend()
#%%
"""
kn = s1.get_knots()
for i in range(len(kn)-1):
    cf = [1, 1, 1, 1] * s1.derivatives(kn[i])
    print("For {0} <= x <= {1}, p(x) = {5}*(x-{0})^3 + {4}*(x-{0})^2 + {3}*(x-{0}) + {2}".format(kn[i], kn[i+1], *cf))
"""
#%% Arrays for Analog as a function of VOltage
# Analog Arrays
A1 = A[V1 != 0]
A2 = A[V2 != 0]
A3 = A[V3 != 0]
A4 = A[V4 != 0]
A5 = A[V5 != 0]
A6 = A[V6 != 0]
A7 = A[V7 != 0]
A8 = A[V8 != 0]
# Voltage Arrays excluding 0 values
V1A = V1[V1 != 0]
V2A = V2[V2 != 0]
V3A = V3[V3 != 0]
V4A = V4[V4 != 0]
V5A = V5[V5 != 0]
V6A = V6[V6 != 0]
V7A = V7[V7 != 0]
V8A = V8[V8 != 0]
# Voltage Uncertainty
dV1 = dV[V1 != 0]
dV2 = dV[V2 != 0]
dV3 = dV[V3 != 0]
dV4 = dV[V4 != 0]
dV5 = dV[V5 != 0]
dV6 = dV[V6 != 0]
dV7 = dV[V7 != 0]
dV8 = dV[V8 != 0]
#%% Analog Signal as a function of Voltage
B.pl.figure()
# Channel 1 A vs V
sa1 = spline(V1A, A1, s = 10)
xsa1 = np.linspace(0.0, 48.86, 1000)
ysa1 = sa1(xsa1)
B.plot_exp(V1A, A1, dV1, label = 'V1')
B.plot_line(xsa1, ysa1, color = 'blue')
# Channel 2 A vs V
sa2 = spline(V3A, A2, s = 10)
xsa2 = np.linspace(0.0, 48.02, 1000)
ysa2 = sa2(xsa2)
B.plot_exp(V2A, A2, dV2, label = 'V2')
B.plot_line(xsa2, ysa2, color = 'orange')
# Channel 3 A vs V
sa3 = spline(V3A, A3, s = 10)
xsa3 = np.linspace(0.0, 47.89, 1000)
ysa3 = sa3(xsa3)
B.plot_exp(V3A, A3, dV3, label = 'V3')
B.plot_line(xsa3, ysa3, color = 'green')
# Channel 4 A vs V
sa4 = spline(V4A, A4, s = 10)
xsa4 = np.linspace(0.0, 48.66, 1000)
ysa4 = sa4(xsa4)
B.plot_exp(V4A, A4, dV4, label = 'V4')
B.plot_line(xsa4, ysa4, color = 'red')
# Channel 5 A vs V
sa5 = spline(V5A, A5, s = 10)
xsa5 = np.linspace(0.0, 47.06, 1000)
ysa5 = sa5(xsa5)
B.plot_exp(V5A, A5, dV5, label = 'V5')
B.plot_line(xsa5, ysa5, color = 'purple')
# Channel 6 A vs V
sa6 = spline(V6A, A6, s = 10)
xsa6 = np.linspace(0.0, 46.84, 1000)
ysa6 = sa6(xsa6)
B.plot_exp(V6A, A6, dV6, label = 'V6')
B.plot_line(xsa6, ysa6, color = 'brown')
# Channel 7 A vs V
sa7 = spline(V7A, A7, s = 10)
xsa7 = np.linspace(0.0, 47.87, 1000)
ysa7 = sa7(xsa7)
B.plot_exp(V7A, A7, dV7, label = 'V7')
B.plot_line(xsa7, ysa7, color = 'pink')
# Channel 8 A vs A
sa8 = spline(V8A, A8, s = 10)
xsa8 = np.linspace(0.0, 47.05, 1000)
ysa8 = sa8(xsa8)
B.plot_exp(V8A, A8, dV8, label = 'V8')
B.plot_line(xsa8, ysa8, color = 'gray')
B.pl.xlabel('Voltage')
B.pl.ylabel('Analog')
B.pl.title('Analog Signal vs Voltage')
B.pl.legend()
#%%